# 『はじめての PHP プロフェッショナル開発』
書籍『はじめての PHP プロフェッショナル開発』のサポートリポジトリです。

このリポジトリの使い方やサンプルコード、環境構築時のFAQなどはwikiをご覧ください。  
https://github.com/php-book/php-qa-plaza/wiki
