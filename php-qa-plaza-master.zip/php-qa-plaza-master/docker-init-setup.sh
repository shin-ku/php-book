cd /var/www/html/app
composer install --no-interaction